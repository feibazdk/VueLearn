<template lang="html">
    <div class="">
        注册组件页面
    </div>
</template>

<script>
export default {
}
</script>

<style>
</style>
