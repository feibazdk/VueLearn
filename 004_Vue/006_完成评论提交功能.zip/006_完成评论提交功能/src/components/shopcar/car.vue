<template lang="html">
    <div class="headerTop">
        我是购物车
    </div>
</template>

<script>
export default {
}
</script>

<style>
</style>
